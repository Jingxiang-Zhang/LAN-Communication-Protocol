def say_hello():
    """
    this tools is building now, please waiting
    :return: none
    """
    print("this tools is building now, please waiting")
