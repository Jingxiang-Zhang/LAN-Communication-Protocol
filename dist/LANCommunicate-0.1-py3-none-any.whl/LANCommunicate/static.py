SYSTEM_TYPE = 0  # 0 for linux OS, 1 for windows OS
PROTOCOL = dict.fromkeys([
    "method",
    "version",
    "data",
    "encrypted",
    "compress"
])
